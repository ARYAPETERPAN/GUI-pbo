package TugasGUI;

import javax.swing.*;

public class CalculatorButton extends JButton {
    public CalculatorButton(String text) {
        super(text);
    }
}